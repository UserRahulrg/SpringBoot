package com.spring_boot_project_many_to_many_bi_directional.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring_boot_project_many_to_many_bi_directional.dao.StudentSubjectDao;
import com.spring_boot_project_many_to_many_bi_directional.object.Student;

@RestController
@Repository
public class StudentSubjectController {

	//private Student student;
	//hibernate,jdbc mocks
	@Autowired
	private StudentSubjectDao dao;
	
	@PostMapping(value="/saveStudent")
	public List<Student> saveStudentDetails(@RequestBody List<Student> student) {
		
		return dao.saveStudentDetailsDao(student);
	}
}

package com.spring_boot_project_many_to_many_bi_directional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjectManyToManyBiDirectionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectManyToManyBiDirectionalApplication.class, args);
	}

}

package com.spring_boot_project_many_to_many_bi_directional.repository;

import javax.security.auth.Subject;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface SubjectRepository extends JpaRepository<Subject,Integer> {

	
}

package com.spring_boot_project_many_to_many_bi_directional.object;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//@Entity
//@Getter
//@Setter
//@Data
public class Student {

	@Id
	private int branchNo;
	private String name;
	private String email;
	private int mobNo;
	private int id;
	
	
	
}

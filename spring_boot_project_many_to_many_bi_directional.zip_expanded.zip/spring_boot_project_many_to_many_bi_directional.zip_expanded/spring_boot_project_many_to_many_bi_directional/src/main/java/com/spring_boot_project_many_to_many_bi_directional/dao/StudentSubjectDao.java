package com.spring_boot_project_many_to_many_bi_directional.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring_boot_project_many_to_many_bi_directional.object.Student;
import com.spring_boot_project_many_to_many_bi_directional.repository.StudentRepository;

@Repository
public class StudentSubjectDao {

	@Autowired
	private StudentRepository studentRepository;
	
	public List<Student> saveStudentDetailsDao(List<Student> student) {
		
		return studentRepository.save(student);
	}
}

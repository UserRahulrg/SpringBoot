package com.spring_boot_project_many_to_many_bi_directional.object;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@Entity
public class Subjects {

	@Id
	private int branchNo;
	private String Eng;
	private String Hin;
	private String San;
	private String Bio;
	private String Math;
	private String Uru;
	
}

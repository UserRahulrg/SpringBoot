package com.spring_boot_project_many_to_many_bi_directional.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;

import com.spring_boot_project_many_to_many_bi_directional.object.Student;


public interface StudentRepository extends JpaRepository<List<Student>,Integer>{

	
}

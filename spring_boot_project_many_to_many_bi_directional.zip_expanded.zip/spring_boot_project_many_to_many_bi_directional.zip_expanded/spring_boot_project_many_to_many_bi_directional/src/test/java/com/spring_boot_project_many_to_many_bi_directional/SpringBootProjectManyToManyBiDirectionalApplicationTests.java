package com.spring_boot_project_many_to_many_bi_directional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectManyToManyBiDirectionalApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.spring_boot_project_many_to_many_bi_directional.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StudentSubjectDaoTest {

	@Test
	void test() {
		
		String s1 = "Hello";
		String p1 = "Hello";
		
		if(s1 == p1)
		{
			System.out.println("Passed");
		}
		else {
			System.out.println("Failed");
		}
		
		//fail("Not yet implemented");
	}

}

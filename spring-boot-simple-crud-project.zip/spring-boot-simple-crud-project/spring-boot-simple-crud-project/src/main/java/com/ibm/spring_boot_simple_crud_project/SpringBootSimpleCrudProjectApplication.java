package com.ibm.spring_boot_simple_crud_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.ibm.spring_simple_rud_project.entity.Employee;

@SpringBootApplication
@ComponentScan(basePackages="com.ibm.spring_simple_rud_project.entity")
@ComponentScan(basePackages="com.ibm.spring_boot_simple_crud_project.repository")
//@ComponentScan(basePackages="com.ibm.spring_boot_simple_crud_project")

public class SpringBootSimpleCrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSimpleCrudProjectApplication.class, args);
		System.out.println("Hi");
		
	    Employee emp = new Employee(1,"Ladka","IT",950000);
	    
	    System.out.println("Name is "+emp.name);
	}

	
}

	
	
	
	
	
	
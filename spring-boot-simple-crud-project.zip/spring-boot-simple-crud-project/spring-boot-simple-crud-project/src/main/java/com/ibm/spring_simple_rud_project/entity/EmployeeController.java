package com.ibm.spring_simple_rud_project.entity;

import java.time.LocalDate;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;

/*
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
*/

//@SpringBootApplication

/*
@RestController
public class EmployeeController {

    @GetMapping("/getTodayDateTime")
    public String getTodayDate() {
    	System.out.println("Hi!");
        return "Today's date is " + LocalDate.now();
    }

    
    
    @GetMapping("/addition/{a}/{b}")
    public int add(@PathVariable("a") int a, @PathVariable("b") int b) {
        return a + b;
    }

 
    @GetMapping(value="/saveEmployee" )
    public Employee saveEmployee( Employee employee) {
        System.out.println(employee);
        // You would typically save the employee to a database or repository here
        return employee;
    }
    																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												
    @GetMapping(value="/demo")
    public String str( String name, String Email,String dob,String image) {
    	 name = "Rahul";
    	 Email = "newrahulgautam@gmail.com";
    	 dob = "06-June-1998";
    	 image = "No image attached";
    	
    	return "\n Username:\n"+name+",  Email: "+Email+",  Dob: "+dob+",  Image attached: "+image;
    }
    

    
}

*/
















/*
package com.ibm.spring_simple_rud_project.entity;

import java.time.LocalDate;

import org.springframework.*;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class EmployeeController {
	
	@RequestMapping(value="/getTodayDate", method = RequestMethod.GET)
	public String getData() {
		
		return "today date is"+LocalDate.now();
	}
	
	@RequestMapping(value="/addition/{a1}/{b1}", method = RequestMethod.GET)
	public int addData(@PathVariable("a1") int a,@PathVariable("b1") int b)
	{
		return a+b;
	}
	
	
	@PostMapping(value="/saveEmployee")
	public Employee saveEmployeeData(Employee employee) {
		
		System.out.println(employee);
		
		return employee;
	}

	
}
	
*/
	


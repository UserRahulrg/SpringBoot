package com.ibm.spring_simple_rud_project.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

public class EmployeeController3 {

	@RestController
	@RequestMapping(value="/employee/api3")
	public class EmployeeController {

		List<Employee> employees = new ArrayList<Employee>();
		
		//Not Working
		@RequestMapping(value = "/getTodayDate3",method = RequestMethod.GET)
		public String getData() {
			
			return "today date is" + LocalDate.now();
		}
		
		//
		@GetMapping(value= "/add3/{a}/{b}/{c}")
		public int getSum(@PathVariable("a") int a,@PathVariable("b") int b,@PathVariable("c") int c) {
			 
			return a+ b +c;
		}
		
		//Required Postman
		@PostMapping(value="/saveEmployee3")
		public Employee saveEmpData(@RequestBody Employee emp) {
			System.out.println(emp);
			return emp;
		}
		
		//Required Postman
		@PostMapping(value ="/saveMultipleEmployee3")
		public List<Employee> saveEmpData(@RequestBody List<Employee> emp){
			
			employees.addAll(emp);
			System.out.println(emp);
			return emp;
		}
		
		//Required Postman
		@GetMapping(value="/getEmployeeById3/{id}")
		public Employee getEmployeeById(@PathVariable("id") int empId) {
			
			for(Employee employee : employees) {
				return employee;
			}
			return null;
		}

		
	}

}

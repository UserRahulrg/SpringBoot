
package com.ibm.spring_boot_simple_crud_project.repository;

/*
import com.ibm.springframework.data.jpa.repository.JpaRepository;
import com.ibm.spring_boot

public class EmployeeRepository extends JpaRepository<Employee,Integer>{

	
}

*/

package com.ibm.spring_boot_crud_project.dao;

/*
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.spring_boot_simple_crud_project.repository.EmployeeRepository;
import com.ibm.spring_simple_rud_project.entity.Employee;


public class EmployeeDao {

	@Autowired
	private EmployeeRepository repository;
	
	public Employee saveEmployeeDao(Employee emp) {
		
		return repository.save(emp);
		
	}
	
	
	public List<Employee> saveMultipleEmployeeDao(List<Employee> emp){
		
		return repository.saveAll(emp);
		
		
	}  
	
	public Employee getEmployeeByIdDao(int empId) {
		
		return repository.findById(empId).orElseThrow();
		
		
	}
	
	public List<Employee> getAllEmployeeDao(){
		
		return repository.findAll();
	}
}

*/

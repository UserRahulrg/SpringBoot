package com.ibm.spring_boot_simple_crud_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSimpleCrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
